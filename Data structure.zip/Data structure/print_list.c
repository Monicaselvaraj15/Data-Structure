#include "sll.h"
void print_list(Slist *head)
{

}
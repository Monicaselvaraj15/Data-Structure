#include "sll.h"
int insert_last(Slist**head,data_t data)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    Slist *new=malloc(sizeof(Slist));
    new->data=data;
    new->link=NULL;
    new=*head;
    if(new==NULL)
    {
        return FAILURE;
    }
    Slist *temp=new;
    while(temp!=NULL)
    {
        //traverse
        *head=temp;
        temp=temp->link;
    }
    return SUCCESS;

}
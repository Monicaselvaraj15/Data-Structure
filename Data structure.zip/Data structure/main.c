#include "sll.h"
int main()
{
    system("clean");
    Slist *head=NULL;
    int key,data,option;
    printf("1.insert last\n2.insert first\n3.delete first\n4.delete last\n5.delete list\n6.find node\n7.print list\n8.Exit");
    while(1)
    {
       scanf("%d",&option);
        switch(option)
        {
            case 1: if(insert_last(&head,data)==FAILURE)
            {
                printf("Insertion failure");
            }
            break;
            case 2: if(insert_first(&head,data)==FAILURE)
            {
                printf("Insertion failure");
            }
            break;
            case 3: if(delete_first(&head)==FAILURE)
            {
                printf("List is empty\n deletion failure");
            }
            else{
                printf("deletion successfully");
            }
            break;
            case 4: if(delete_last(&head)==FAILURE)
            {
                printf("INFO : list is empty\ndeletion failure");
            }
            else{
                printf("deletion successfully");
            }
            break;
            case 5: if(delete_list(&head)==FAILURE)
            {
                printf("INFO:list is empty\ndeletion failure");
            }
            else{
                printf("deletion successfully");
            }
            break;
            case 6:
            printf("Enter the key:");
            scanf("%d",&key);
            int count;
            if (count==find_node(head,key)==FAILURE)
            {
                printf("INFO list is empty\nfailed to find");
            }
            else
            {
               printf("%d found in the list at the position %d\n", key, count);
            }
            break;
            case 7:
             print_list(head);
             break;
             case 8:
               return SUCCESS;
               default:printf("Enter a proper choice");
               break;
        }
    }

}
#include "sll.h"
int delete_last(Slist **head)
{
    if(head==NULL)
    {
        return LIST_EMPTY;
    }
}
#include "sll.h"
int delete_first(Slist **head)
{
    if(*head==NULL)//check head null or not
    {
        return LIST_EMPTY;
    }
    Slist *temp=*head;
    *head=temp->link;//update head
    free(temp);//delete temp
}

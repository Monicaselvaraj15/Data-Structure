#ifndef sll_h
#define sll_h
#include<stdio.h>
#include<stdlib.h>
#define SUCCESS 0
#define FAILURE -1
#define LIST_EMPTY -2
#define DATA_NOT_FOUND -3

typedef int data_t;
typedef struct node
{
    data_t data;
    struct node *link;
}Slist;
int insert_last(Slist **head, data_t);
int insert_first(Slist **head,data_t);
int delete_first(Slist **);
int delete_last(Slist **);
int delete_list(Slist **);
int find_node(Slist *head,data_t key);
void print_list(Slist *head);
#endif
